"""
jobs/__init__.py
------------------
طبقة الوصول لقاعدة بيانات SQLite الخاصة بالمهام (Jobs).
تحتوي على دوال: إنشاء، تحديث، قراءة، وحذف المهام.

جدول jobs:
    id          TEXT PRIMARY KEY
    status      TEXT  (queued, processing, completed, failed)
    progress    INTEGER (0-100)
    stage       TEXT  (المرحلة الحالية من المعالجة)
    language    TEXT  (لغة الهدف المختارة)
    source_lang TEXT  (اللغة المكتشفة تلقائياً)
    created_at  TEXT
    updated_at  TEXT
    error       TEXT
    output_path TEXT
    srt_path    TEXT
    vtt_path    TEXT
    voice_clone INTEGER (0/1)
    burn_subs   INTEGER (0/1)
"""

import sqlite3
import threading
from datetime import datetime, timezone

from app.settings import DB_PATH

# قفل لمنع تضارب الكتابة المتزامنة على SQLite من عدة Threads
_db_lock = threading.Lock()


def get_connection():
    """فتح اتصال جديد بقاعدة البيانات (SQLite ليست آمنة عبر Threads إلا بهذا الشكل)."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """إنشاء جدول jobs إن لم يكن موجوداً. تُستدعى عند بدء تشغيل التطبيق."""
    with _db_lock:
        conn = get_connection()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'queued',
                progress INTEGER NOT NULL DEFAULT 0,
                stage TEXT DEFAULT '',
                language TEXT,
                source_lang TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                error TEXT,
                output_path TEXT,
                srt_path TEXT,
                vtt_path TEXT,
                voice_clone INTEGER DEFAULT 1,
                burn_subs INTEGER DEFAULT 0
            )
        """)
        conn.commit()
        conn.close()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_job(job_id: str, language: str, voice_clone: bool, burn_subs: bool):
    """إدراج مهمة جديدة بحالة queued."""
    with _db_lock:
        conn = get_connection()
        conn.execute(
            """INSERT INTO jobs (id, status, progress, stage, language, created_at, updated_at, voice_clone, burn_subs)
               VALUES (?, 'queued', 0, 'في الانتظار', ?, ?, ?, ?, ?)""",
            (job_id, language, _now(), _now(), int(voice_clone), int(burn_subs)),
        )
        conn.commit()
        conn.close()


def update_job(job_id: str, **fields):
    """
    تحديث أي حقول في سجل المهمة.
    مثال: update_job(job_id, status="processing", progress=20, stage="استخراج الصوت")
    """
    if not fields:
        return
    fields["updated_at"] = _now()
    set_clause = ", ".join(f"{k} = ?" for k in fields.keys())
    values = list(fields.values()) + [job_id]
    with _db_lock:
        conn = get_connection()
        conn.execute(f"UPDATE jobs SET {set_clause} WHERE id = ?", values)
        conn.commit()
        conn.close()


def get_job(job_id: str) -> dict | None:
    """جلب بيانات مهمة واحدة عبر معرفها."""
    with _db_lock:
        conn = get_connection()
        row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        conn.close()
    return dict(row) if row else None


def list_jobs(limit: int = 50) -> list[dict]:
    """جلب آخر المهام مرتبة تنازلياً حسب تاريخ الإنشاء."""
    with _db_lock:
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
    return [dict(r) for r in rows]


def delete_job(job_id: str):
    """حذف سجل مهمة من قاعدة البيانات."""
    with _db_lock:
        conn = get_connection()
        conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
        conn.commit()
        conn.close()
