"""
main.py
---------
نقطة الدخول الرئيسية للتطبيق. يقوم بـ:
- تهيئة تطبيق FastAPI
- تهيئة قاعدة البيانات
- تسجيل المسارات (routes)
- تقديم صفحة الواجهة الرئيسية
- تشغيل مهمة دورية في الخلفية لتنظيف الملفات القديمة
- إعداد نظام تسجيل الأخطاء (logging)
"""

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

from app import jobs
from app.settings import BASE_DIR, LOG_DIR, FILE_RETENTION_HOURS
from app.file_manager import cleanup_old_files
from app.routes import router

# ===================== إعداد نظام تسجيل الأخطاء =====================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "app.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("main")


async def periodic_cleanup_task():
    """مهمة دورية تعمل في الخلفية لحذف الملفات القديمة كل ساعة."""
    while True:
        try:
            cleanup_old_files()
        except Exception as e:
            logger.error(f"خطأ في مهمة التنظيف الدورية: {e}")
        await asyncio.sleep(3600)  # كل ساعة


@asynccontextmanager
async def lifespan(app: FastAPI):
    """تهيئة الموارد عند بدء التشغيل، وتنظيفها عند الإغلاق."""
    logger.info("بدء تشغيل AI Video Translator...")
    jobs.init_db()
    cleanup_task = asyncio.create_task(periodic_cleanup_task())
    yield
    cleanup_task.cancel()
    logger.info("تم إيقاف التطبيق.")


app = FastAPI(title="AI Video Translator", lifespan=lifespan)

# تسجيل مسارات الـ API
app.include_router(router)

# تقديم الملفات الثابتة (إن وجدت لاحقاً: CSS/JS منفصلة)
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """تقديم صفحة الواجهة الرئيسية."""
    return templates.TemplateResponse("index.html", {"request": request})


# ===================== معالجة الأخطاء العامة =====================
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception(f"خطأ غير متوقع في {request.url}: {exc}")
    from fastapi.responses import JSONResponse
    return JSONResponse(
        status_code=500,
        content={"detail": "حدث خطأ غير متوقع في الخادم. تم تسجيل الخطأ للمراجعة."},
    )


if __name__ == "__main__":
    import uvicorn
    from app.settings import HOST, PORT
    uvicorn.run("app.main:app", host=HOST, port=PORT, reload=True)
