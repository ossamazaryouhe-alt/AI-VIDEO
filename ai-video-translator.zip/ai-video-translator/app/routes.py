"""
routes.py
-----------
يحتوي على كل مسارات (Endpoints) الـ API:

POST /api/upload          - رفع فيديو وبدء مهمة ترجمة جديدة
GET  /api/translate        - (إعادة) تشغيل مهمة ترجمة - متوافق مع المتطلبات
GET  /api/jobs/{job_id}     - الاستعلام عن حالة مهمة (تستخدم أيضاً عبر SSE)
GET  /api/jobs/{job_id}/stream - بث حي لحالة المهمة عبر Server-Sent Events
GET  /api/download/{job_id}/{filename} - تنزيل الفيديو النهائي أو ملفات الترجمة
GET  /api/languages        - قائمة اللغات المدعومة
GET  /api/health           - فحص صحة الخدمة
"""

import asyncio
import json
import logging

from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, StreamingResponse

from app import jobs
from app.file_manager import (
    generate_job_id, sanitize_filename, validate_video_file, create_job_dirs,
)
from app.video_processor import process_video_job
from app.queue_manager import submit_job
from app.settings import SUPPORTED_LANGUAGES

logger = logging.getLogger("routes")
router = APIRouter()


@router.get("/api/health")
async def health_check():
    """فحص بسيط للتأكد من أن الخدمة تعمل."""
    return {"status": "ok", "service": "ai-video-translator"}


@router.get("/api/languages")
async def get_languages():
    """إرجاع قائمة اللغات المدعومة للترجمة."""
    return {
        code: info["name"] for code, info in SUPPORTED_LANGUAGES.items()
    }


@router.post("/api/upload")
async def upload_video(
    file: UploadFile = File(...),
    target_lang: str = Form(...),
    voice_clone: bool = Form(True),
    burn_subs: bool = Form(False),
    generate_subs: bool = Form(True),
):
    """
    رفع فيديو جديد وبدء معالجته تلقائياً (إنشاء Job + إضافته للطابور).
    """
    if target_lang not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail="اللغة الهدف غير مدعومة")

    # قراءة محتوى الملف للتحقق من الحجم الفعلي
    content = await file.read()
    file_size = len(content)

    safe_filename = sanitize_filename(file.filename or "video")
    is_valid, error_msg = validate_video_file(safe_filename, file_size)
    if not is_valid:
        raise HTTPException(status_code=400, detail=error_msg)

    job_id = generate_job_id()
    paths = create_job_dirs(job_id)

    video_path = paths["upload_dir"] / safe_filename
    with open(video_path, "wb") as f:
        f.write(content)

    # إنشاء سجل المهمة في قاعدة البيانات بحالة queued
    jobs.create_job(job_id, target_lang, voice_clone, burn_subs)

    # إضافة المهمة إلى الطابور المحلي للمعالجة في الخلفية
    submit_job(
        process_video_job,
        job_id=job_id,
        original_filename=safe_filename,
        target_lang=target_lang,
        voice_clone_enabled=voice_clone,
        burn_subs=burn_subs,
        generate_subs=generate_subs,
    )

    logger.info(f"تم رفع فيديو جديد وإنشاء مهمة: {job_id}")
    return {"job_id": job_id, "status": "queued"}


@router.get("/api/translate")
async def retry_translate(job_id: str):
    """
    إعادة تشغيل مهمة موجودة (مثلاً بعد فشلها) دون الحاجة لرفع الفيديو مجدداً.
    """
    job = jobs.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="المهمة غير موجودة")

    from app.settings import UPLOAD_DIR
    upload_dir = UPLOAD_DIR / job_id
    files = list(upload_dir.glob("*")) if upload_dir.exists() else []
    if not files:
        raise HTTPException(status_code=400, detail="ملف الفيديو الأصلي غير موجود لإعادة المعالجة")

    jobs.update_job(job_id, status="queued", progress=0, stage="في الانتظار", error=None)
    submit_job(
        process_video_job,
        job_id=job_id,
        original_filename=files[0].name,
        target_lang=job["language"],
        voice_clone_enabled=bool(job["voice_clone"]),
        burn_subs=bool(job["burn_subs"]),
        generate_subs=True,
    )
    return {"job_id": job_id, "status": "queued"}


@router.get("/api/jobs/{job_id}")
async def get_job_status(job_id: str):
    """الاستعلام عن حالة مهمة معينة (طلب عادي وليس بث حي)."""
    job = jobs.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="المهمة غير موجودة")
    return job


@router.get("/api/jobs/{job_id}/stream")
async def stream_job_status(job_id: str):
    """
    بث حي (Server-Sent Events) لحالة المهمة، يُستخدم لتحديث شريط
    التقدم في الواجهة الأمامية لحظة بلحظة دون الحاجة لـ Polling يدوي.
    """
    async def event_generator():
        last_payload = None
        while True:
            job = jobs.get_job(job_id)
            if not job:
                yield f"data: {json.dumps({'error': 'job_not_found'})}\n\n"
                break

            payload = json.dumps(job, ensure_ascii=False, default=str)
            if payload != last_payload:
                yield f"data: {payload}\n\n"
                last_payload = payload

            if job["status"] in ("completed", "failed"):
                break

            await asyncio.sleep(1)

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@router.get("/api/download/{job_id}/{kind}")
async def download_result(job_id: str, kind: str):
    """
    تنزيل نتيجة المهمة. kind يمكن أن تكون: video, srt, vtt
    """
    job = jobs.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="المهمة غير موجودة")
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail="المهمة لم تكتمل بعد")

    path_map = {
        "video": (job.get("output_path"), "video/mp4", "translated_video.mp4"),
        "srt": (job.get("srt_path"), "text/plain", "subtitles.srt"),
        "vtt": (job.get("vtt_path"), "text/vtt", "subtitles.vtt"),
    }

    if kind not in path_map:
        raise HTTPException(status_code=400, detail="نوع الملف غير صالح")

    file_path, media_type, download_name = path_map[kind]
    if not file_path:
        raise HTTPException(status_code=404, detail="الملف المطلوب غير متوفر لهذه المهمة")

    return FileResponse(file_path, media_type=media_type, filename=download_name)
