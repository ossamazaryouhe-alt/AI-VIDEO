"""
settings.py
------------
ملف الإعدادات المركزي للمشروع.
يحتوي على كل القيم القابلة للتعديل: المسارات، حدود الملفات،
اللغات المدعومة، إعدادات النماذج، وإعدادات الـ Queue.
يتم تحميل القيم من متغيرات البيئة (.env) مع قيم افتراضية آمنة.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# تحميل متغيرات البيئة من ملف .env إن وجد
load_dotenv()

# ===================== المسارات الأساسية =====================
BASE_DIR = Path(__file__).resolve().parent.parent

UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
TEMP_DIR = BASE_DIR / "temp"
LOG_DIR = BASE_DIR / "logs"
DB_PATH = BASE_DIR / "jobs.db"

# إنشاء المجلدات إن لم تكن موجودة
for d in [UPLOAD_DIR, OUTPUT_DIR, TEMP_DIR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ===================== حدود الملفات =====================
# الحد الأقصى لحجم الفيديو المرفوع (بالميجابايت)
MAX_UPLOAD_SIZE_MB = int(os.getenv("MAX_UPLOAD_SIZE_MB", 500))
MAX_UPLOAD_SIZE_BYTES = MAX_UPLOAD_SIZE_MB * 1024 * 1024

# امتدادات الفيديو المسموح بها فقط
ALLOWED_VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}

# مدة الاحتفاظ بالملفات القديمة قبل حذفها تلقائياً (بالساعات)
FILE_RETENTION_HOURS = int(os.getenv("FILE_RETENTION_HOURS", 24))

# ===================== إعدادات الـ Queue =====================
# أقصى عدد من المهام التي تعمل بالتوازي
MAX_CONCURRENT_JOBS = int(os.getenv("MAX_CONCURRENT_JOBS", 1))

# ===================== إعدادات Whisper =====================
# الحجم الافتراضي لنموذج Whisper: tiny, base, small, medium, large-v3
WHISPER_MODEL_SIZE = os.getenv("WHISPER_MODEL_SIZE", "small")
# نوع الجهاز: cpu أو cuda
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
# نوع الحساب: int8 للأداء الأفضل على CPU، float16 لكروت GPU
WHISPER_COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "int8")

# ===================== إعدادات الترجمة (NLLB) =====================
NLLB_MODEL_NAME = os.getenv("NLLB_MODEL_NAME", "facebook/nllb-200-distilled-600M")

# ===================== إعدادات استنساخ الصوت (XTTS) =====================
XTTS_MODEL_NAME = os.getenv("XTTS_MODEL_NAME", "tts_models/multilingual/multi-dataset/xtts_v2")
# تفعيل استنساخ الصوت افتراضياً
DEFAULT_VOICE_CLONE_ENABLED = os.getenv("DEFAULT_VOICE_CLONE_ENABLED", "true").lower() == "true"

# ===================== اللغات المدعومة =====================
# كود اللغة بصيغة Whisper -> الاسم المعروض بالعربية
# وكود NLLB المقابل لكل لغة (Flores-200 codes)
SUPPORTED_LANGUAGES = {
    "ar": {"name": "العربية", "nllb": "arb_Arab"},
    "en": {"name": "الإنجليزية", "nllb": "eng_Latn"},
    "fr": {"name": "الفرنسية", "nllb": "fra_Latn"},
    "es": {"name": "الإسبانية", "nllb": "spa_Latn"},
    "de": {"name": "الألمانية", "nllb": "deu_Latn"},
    "it": {"name": "الإيطالية", "nllb": "ita_Latn"},
    "pt": {"name": "البرتغالية", "nllb": "por_Latn"},
    "ru": {"name": "الروسية", "nllb": "rus_Cyrl"},
    "tr": {"name": "التركية", "nllb": "tur_Latn"},
    "zh": {"name": "الصينية", "nllb": "zho_Hans"},
    "ja": {"name": "اليابانية", "nllb": "jpn_Jpan"},
    "ko": {"name": "الكورية", "nllb": "kor_Hang"},
    "hi": {"name": "الهندية", "nllb": "hin_Deva"},
    "fa": {"name": "الفارسية", "nllb": "pes_Arab"},
    "ur": {"name": "الأردية", "nllb": "urd_Arab"},
}

# ===================== إعدادات السيرفر =====================
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))

# مفتاح سري بسيط لتنظيف أسماء الملفات (ليس API key مدفوع)
SECRET_SALT = os.getenv("SECRET_SALT", "ai-video-translator-salt")
