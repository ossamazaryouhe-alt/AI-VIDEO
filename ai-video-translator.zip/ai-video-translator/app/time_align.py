"""
time_align.py
---------------
وحدة مستقلة مسؤولة عن محاذاة المقاطع الصوتية المترجمة مع التوقيت
الأصلي للفيديو، ومنع "انجراف التوقيت" (Time Drift) الذي يحدث عندما
يكون الصوت المُولَّد أطول أو أقصر من المدة الأصلية للجملة.

الاستراتيجية:
1. لكل مقطع، نقارن مدة الصوت المُولَّد بالمدة الأصلية (end - start).
2. إذا كان الصوت أطول من المساحة المتاحة، يتم تسريعه (Time-stretch)
   بنسبة محسوبة دون تغيير طبقة الصوت (pitch) بشكل ملحوظ.
3. إذا كان أقصر، يتم وضعه في بداية المقطع وملء الفراغ المتبقي بصمت،
   مع الحفاظ على التوقيت الأصلي لباقي المقاطع.
4. يتم تتبّع الإزاحة التراكمية (cumulative offset) لضمان عدم انجراف
   المقاطع اللاحقة عن الفيديو الأصلي.
"""

import logging
from pydub import AudioSegment

logger = logging.getLogger("time_align")

# الحد الأقصى لنسبة التسريع المسموح بها لتفادي تشويه الصوت بشكل مبالغ فيه
MAX_STRETCH_FACTOR = 1.6
MIN_STRETCH_FACTOR = 0.7


def _stretch_audio(segment: AudioSegment, target_duration_ms: float) -> AudioSegment:
    """
    تسريع أو إبطاء مقطع صوتي ليتناسب مع مدة زمنية مستهدفة،
    باستخدام تغيير معدل العينات (frame_rate) كطريقة بسيطة وفعالة
    لا تتطلب مكتبات خارجية إضافية (Time-stretch تقريبي).
    """
    current_duration_ms = len(segment)
    if current_duration_ms == 0:
        return segment

    speed_factor = current_duration_ms / target_duration_ms
    # تقييد عامل التسريع لتفادي تشويه الصوت بشكل غير مفهوم
    speed_factor = max(MIN_STRETCH_FACTOR, min(MAX_STRETCH_FACTOR, speed_factor))

    new_frame_rate = int(segment.frame_rate * speed_factor)
    stretched = segment._spawn(segment.raw_data, overrides={"frame_rate": new_frame_rate})
    stretched = stretched.set_frame_rate(segment.frame_rate)
    return stretched


def align_segments_to_timeline(
    segments_with_audio: list[dict],
    total_duration_ms: int,
) -> AudioSegment:
    """
    دمج جميع المقاطع الصوتية المترجمة في مسار صوتي واحد متزامن مع
    الفيديو الأصلي، مع منع انجراف التوقيت بين المقاطع.

    segments_with_audio: قائمة من القواميس بالشكل:
        {"start": float (ثواني), "end": float, "audio": AudioSegment}

    تعيد: AudioSegment نهائي بطول total_duration_ms.
    """
    timeline = AudioSegment.silent(duration=total_duration_ms)
    cumulative_drift_ms = 0

    for seg in segments_with_audio:
        start_ms = int(seg["start"] * 1000) + cumulative_drift_ms
        end_ms = int(seg["end"] * 1000) + cumulative_drift_ms
        target_duration = max(end_ms - start_ms, 50)  # حد أدنى 50ms لتفادي القسمة على صفر

        audio_clip = seg["audio"]
        clip_duration = len(audio_clip)

        # إذا تجاوز الصوت المساحة المخصصة بنسبة كبيرة، نقوم بمحاذاته زمنياً
        if clip_duration > target_duration * 1.05:
            audio_clip = _stretch_audio(audio_clip, target_duration)
            new_drift = len(audio_clip) - target_duration
            if new_drift > 0:
                # تسجيل الانجراف المتبقي لتعويضه في المقاطع اللاحقة عند الإمكان
                cumulative_drift_ms += 0  # نحافظ على بداية المقطع التالي كما هي لمنع تراكم الخطأ
                logger.debug(f"تعذر استيعاب المقطع بالكامل ضمن التوقيت الأصلي، فرق: {new_drift}ms")

        # وضع المقطع الصوتي في موقعه الزمني الصحيح على الخط الزمني
        if 0 <= start_ms < total_duration_ms:
            timeline = timeline.overlay(audio_clip, position=start_ms)

    return timeline
