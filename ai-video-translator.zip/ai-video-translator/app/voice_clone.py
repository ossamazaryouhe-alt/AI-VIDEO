"""
voice_clone.py
----------------
يستخدم Coqui XTTS-v2 (نموذج TTS مفتوح المصدر يدعم استنساخ الصوت
من عينة صوتية قصيرة) لتوليد صوت مترجم يحاكي صوت المتحدث الأصلي
في الفيديو.

في حال تعطيل استنساخ الصوت، يتم استخدام صوت افتراضي مدمج بالنموذج
لكل لغة (Built-in Speaker) بدلاً من الاستنساخ.
"""

import logging
from pathlib import Path
from TTS.api import TTS

from app.settings import XTTS_MODEL_NAME

logger = logging.getLogger("voice_clone")

_tts_instance = None

# أسماء متحدثين افتراضيين مدمجين بنموذج XTTS-v2 (في حال تعطيل الاستنساخ)
DEFAULT_SPEAKER = "Claribel Dervla"


def get_tts() -> TTS:
    """تحميل نموذج XTTS-v2 مرة واحدة فقط (Singleton)."""
    global _tts_instance
    if _tts_instance is None:
        logger.info(f"تحميل نموذج استنساخ الصوت {XTTS_MODEL_NAME}...")
        _tts_instance = TTS(XTTS_MODEL_NAME)
        logger.info("تم تحميل نموذج استنساخ الصوت بنجاح.")
    return _tts_instance


def generate_cloned_speech(
    text: str,
    target_lang: str,
    output_path: str,
    speaker_wav_path: str | None = None,
    voice_clone_enabled: bool = True,
):
    """
    توليد ملف صوتي لجملة واحدة باللغة الهدف.

    - إذا كان voice_clone_enabled=True ووُجد speaker_wav_path:
      يتم استنساخ صوت المتحدث الأصلي من عينة الصوت المستخرجة من الفيديو.
    - إذا كان False أو لم تتوفر عينة صوت:
      يتم استخدام متحدث افتراضي مدمج بالنموذج.
    """
    if not text.strip():
        # إنشاء ملف صوت صامت قصير لتفادي كسر تسلسل المقاطع
        text = " "

    tts = get_tts()

    try:
        if voice_clone_enabled and speaker_wav_path and Path(speaker_wav_path).exists():
            tts.tts_to_file(
                text=text,
                speaker_wav=speaker_wav_path,
                language=target_lang,
                file_path=output_path,
            )
        else:
            tts.tts_to_file(
                text=text,
                speaker=DEFAULT_SPEAKER,
                language=target_lang,
                file_path=output_path,
            )
    except Exception as e:
        logger.error(f"فشل توليد الصوت للنص '{text[:30]}...': {e}")
        raise


def extract_speaker_sample(audio_path: str, output_sample_path: str, duration_sec: int = 15):
    """
    استخراج عينة قصيرة من الصوت الأصلي (أول 15 ثانية تقريباً)
    لاستخدامها كمرجع لاستنساخ الصوت عبر XTTS.
    """
    from pydub import AudioSegment

    audio = AudioSegment.from_file(audio_path)
    sample = audio[: duration_sec * 1000]
    sample.export(output_sample_path, format="wav")
    logger.info(f"تم استخراج عينة صوت المتحدث: {output_sample_path}")
    return output_sample_path
