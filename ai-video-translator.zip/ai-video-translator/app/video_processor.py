"""
video_processor.py
---------------------
المنسق الرئيسي (Orchestrator) لكامل خط أنابيب معالجة الفيديو:

الفيديو -> استخراج الصوت -> Whisper -> اكتشاف اللغة -> ترجمة النص
-> توليد صوت مترجم -> Time Alignment -> دمج الصوت -> توليد SRT/VTT
-> حرق الترجمة (اختياري) -> فيديو نهائي

كل خطوة تُحدِّث حالة المهمة (progress, stage) في قاعدة البيانات
ليتمكن الـ Frontend من متابعتها عبر SSE.
"""

import logging
import subprocess
from pathlib import Path

from pydub import AudioSegment

from app import jobs
from app.file_manager import create_job_dirs, cleanup_temp_dir
from app.whisper_engine import transcribe_audio
from app.translator import translate_segments
from app.voice_clone import generate_cloned_speech, extract_speaker_sample
from app.time_align import align_segments_to_timeline
from app.subtitle_generator import generate_srt, generate_vtt
from app.settings import SUPPORTED_LANGUAGES

logger = logging.getLogger("video_processor")


def _run_ffmpeg(cmd: list[str]):
    """تشغيل أمر FFmpeg مع التقاط الأخطاء وتسجيلها."""
    logger.debug(f"تشغيل FFmpeg: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(f"فشل أمر FFmpeg: {result.stderr}")
        raise RuntimeError(f"خطأ في FFmpeg: {result.stderr[-500:]}")
    return result


def _extract_audio(video_path: Path, audio_out: Path):
    """استخراج المسار الصوتي من الفيديو كملف WAV (16kHz, mono) مناسب لـ Whisper."""
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vn", "-ac", "1", "-ar", "16000", "-acodec", "pcm_s16le",
        str(audio_out),
    ]
    _run_ffmpeg(cmd)


def _get_video_duration_ms(video_path: Path) -> int:
    """الحصول على مدة الفيديو بالميلي ثانية باستخدام ffprobe."""
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(video_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    duration_sec = float(result.stdout.strip())
    return int(duration_sec * 1000)


def _mux_audio_with_video(video_path: Path, audio_path: Path, output_path: Path):
    """دمج المسار الصوتي الجديد مع الفيديو الأصلي (استبدال الصوت القديم)."""
    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path),
        "-i", str(audio_path),
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "copy", "-c:a", "aac", "-shortest",
        str(output_path),
    ]
    _run_ffmpeg(cmd)


def _burn_subtitles(video_path: Path, srt_path: Path, output_path: Path):
    """حرق ملف الترجمة داخل الفيديو بشكل مرئي دائم."""
    # على ويندوز يجب escaping للمسار، هنا نفترض بيئة Linux/Mac
    srt_escaped = str(srt_path).replace(":", "\\:")
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vf", f"subtitles={srt_escaped}",
        "-c:a", "copy",
        str(output_path),
    ]
    _run_ffmpeg(cmd)


def process_video_job(
    job_id: str,
    original_filename: str,
    target_lang: str,
    voice_clone_enabled: bool,
    burn_subs: bool,
    generate_subs: bool,
):
    """
    الدالة الرئيسية التي تُشغَّل في الخلفية (Worker) لمعالجة فيديو كامل.
    يتم استدعاؤها عبر queue_manager.submit_job().
    """
    try:
        paths = create_job_dirs(job_id)
        upload_dir, temp_dir, output_dir = paths["upload_dir"], paths["temp_dir"], paths["output_dir"]
        video_path = upload_dir / original_filename

        jobs.update_job(job_id, status="processing", progress=5, stage="استخراج الصوت")

        # ===== 1. استخراج الصوت =====
        audio_path = temp_dir / "audio.wav"
        _extract_audio(video_path, audio_path)
        total_duration_ms = _get_video_duration_ms(video_path)

        jobs.update_job(job_id, progress=15, stage="التعرف على الكلام")

        # ===== 2. Whisper: التعرف على الكلام + اكتشاف اللغة =====
        transcription = transcribe_audio(str(audio_path))
        source_lang = transcription["language"]
        segments = transcription["segments"]

        if source_lang not in SUPPORTED_LANGUAGES:
            logger.warning(f"اللغة المكتشفة {source_lang} غير مدعومة رسمياً، سيتم استخدام الإنجليزية كافتراضي للترجمة")

        jobs.update_job(job_id, progress=35, stage="الترجمة", source_lang=source_lang)

        # ===== 3. ترجمة النصوص =====
        translated_segments = translate_segments(segments, source_lang, target_lang)

        jobs.update_job(job_id, progress=50, stage="استنساخ الصوت")

        # ===== 4. استخراج عينة صوت المتحدث (لاستنساخ الصوت) =====
        speaker_sample_path = None
        if voice_clone_enabled:
            speaker_sample_path = str(temp_dir / "speaker_sample.wav")
            extract_speaker_sample(str(audio_path), speaker_sample_path)

        # ===== 5. توليد صوت مترجم لكل مقطع =====
        segments_with_audio = []
        for i, seg in enumerate(translated_segments):
            seg_audio_path = temp_dir / f"seg_{i:04d}.wav"
            generate_cloned_speech(
                text=seg["translated_text"],
                target_lang=target_lang,
                output_path=str(seg_audio_path),
                speaker_wav_path=speaker_sample_path,
                voice_clone_enabled=voice_clone_enabled,
            )
            audio_clip = AudioSegment.from_file(seg_audio_path)
            segments_with_audio.append({
                "start": seg["start"],
                "end": seg["end"],
                "audio": audio_clip,
            })

        jobs.update_job(job_id, progress=75, stage="محاذاة الوقت")

        # ===== 6. محاذاة الوقت ومنع الانجراف =====
        final_audio = align_segments_to_timeline(segments_with_audio, total_duration_ms)
        final_audio_path = temp_dir / "final_audio.wav"
        final_audio.export(final_audio_path, format="wav")

        jobs.update_job(job_id, progress=85, stage="دمج الصوت")

        # ===== 7. دمج الصوت الجديد مع الفيديو =====
        muxed_video_path = temp_dir / "muxed_video.mp4"
        _mux_audio_with_video(video_path, final_audio_path, muxed_video_path)

        jobs.update_job(job_id, progress=90, stage="إنشاء الترجمة")

        # ===== 8. توليد ملفات الترجمة SRT / VTT =====
        srt_path, vtt_path = None, None
        if generate_subs:
            srt_path = output_dir / "subtitles.srt"
            vtt_path = output_dir / "subtitles.vtt"
            generate_srt(translated_segments, str(srt_path))
            generate_vtt(translated_segments, str(vtt_path))

        jobs.update_job(job_id, progress=95, stage="إنهاء الفيديو")

        # ===== 9. حرق الترجمة (اختياري) =====
        final_output_path = output_dir / "final_video.mp4"
        if burn_subs and srt_path:
            _burn_subtitles(muxed_video_path, srt_path, final_output_path)
        else:
            final_output_path.write_bytes(muxed_video_path.read_bytes())

        # ===== 10. إنهاء المهمة بنجاح =====
        jobs.update_job(
            job_id,
            status="completed",
            progress=100,
            stage="مكتمل",
            output_path=str(final_output_path),
            srt_path=str(srt_path) if srt_path else None,
            vtt_path=str(vtt_path) if vtt_path else None,
        )
        logger.info(f"اكتملت معالجة المهمة {job_id} بنجاح.")

    except Exception as e:
        logger.exception(f"فشلت معالجة المهمة {job_id}")
        jobs.update_job(job_id, status="failed", error=str(e), stage="فشل")
    finally:
        # تنظيف الملفات المؤقتة دائماً سواء نجحت المعالجة أو فشلت
        cleanup_temp_dir(job_id)
