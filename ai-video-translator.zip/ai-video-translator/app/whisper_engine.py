"""
whisper_engine.py
-------------------
يستخدم faster-whisper (نسخة محسّنة وسريعة من Whisper تعمل بكفاءة على CPU)
لتفريغ الصوت إلى نص مع الطوابع الزمنية (timestamps) لكل جملة،
واكتشاف لغة الفيديو تلقائياً.

النموذج يُحمَّل مرة واحدة فقط (Singleton) لتفادي إعادة التحميل المكلف
في كل طلب.
"""

import logging
from faster_whisper import WhisperModel

from app.settings import WHISPER_MODEL_SIZE, WHISPER_DEVICE, WHISPER_COMPUTE_TYPE

logger = logging.getLogger("whisper_engine")

_model_instance = None


def get_model() -> WhisperModel:
    """تحميل نموذج Whisper مرة واحدة فقط (Lazy Singleton)."""
    global _model_instance
    if _model_instance is None:
        logger.info(f"تحميل نموذج Whisper ({WHISPER_MODEL_SIZE}) على {WHISPER_DEVICE}...")
        _model_instance = WhisperModel(
            WHISPER_MODEL_SIZE,
            device=WHISPER_DEVICE,
            compute_type=WHISPER_COMPUTE_TYPE,
        )
        logger.info("تم تحميل نموذج Whisper بنجاح.")
    return _model_instance


def transcribe_audio(audio_path: str) -> dict:
    """
    تفريغ ملف صوتي إلى نص مع طوابع زمنية لكل جملة.

    تعيد قاموساً بالشكل:
    {
        "language": "ar",          # اللغة المكتشفة
        "language_probability": 0.98,
        "segments": [
            {"start": 0.0, "end": 3.2, "text": "..."},
            ...
        ]
    }
    """
    model = get_model()

    # vad_filter=True يزيل فترات الصمت تلقائياً مما يحسّن الدقة والسرعة
    segments_iter, info = model.transcribe(
        audio_path,
        beam_size=5,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500),
    )

    segments = []
    for seg in segments_iter:
        segments.append({
            "start": round(seg.start, 3),
            "end": round(seg.end, 3),
            "text": seg.text.strip(),
        })

    result = {
        "language": info.language,
        "language_probability": round(info.language_probability, 3),
        "segments": segments,
    }

    logger.info(
        f"تم التعرف على اللغة: {result['language']} "
        f"(دقة: {result['language_probability']}) - عدد المقاطع: {len(segments)}"
    )
    return result
