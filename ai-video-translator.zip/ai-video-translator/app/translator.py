"""
translator.py
---------------
يستخدم نموذج NLLB-200 (No Language Left Behind) من Meta عبر مكتبة
transformers لترجمة النصوص بين أكثر من 200 لغة، بشكل محلي بالكامل
وبدون أي API مدفوع.

النموذج والـ Tokenizer يُحمَّلان مرة واحدة فقط (Singleton).
"""

import logging
import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

from app.settings import NLLB_MODEL_NAME, SUPPORTED_LANGUAGES

logger = logging.getLogger("translator")

_tokenizer = None
_model = None


def _load_model():
    """تحميل نموذج NLLB والـ Tokenizer مرة واحدة فقط."""
    global _tokenizer, _model
    if _model is None:
        logger.info(f"تحميل نموذج الترجمة {NLLB_MODEL_NAME}...")
        _tokenizer = AutoTokenizer.from_pretrained(NLLB_MODEL_NAME)
        _model = AutoModelForSeq2SeqLM.from_pretrained(NLLB_MODEL_NAME)
        _model.eval()
        logger.info("تم تحميل نموذج الترجمة بنجاح.")
    return _tokenizer, _model


def _nllb_code(lang_code: str) -> str:
    """تحويل كود اللغة المختصر (مثل ar) إلى كود NLLB الكامل (مثل arb_Arab)."""
    lang_info = SUPPORTED_LANGUAGES.get(lang_code)
    if not lang_info:
        raise ValueError(f"اللغة غير مدعومة: {lang_code}")
    return lang_info["nllb"]


def translate_text(text: str, source_lang: str, target_lang: str) -> str:
    """ترجمة نص واحد من اللغة المصدر إلى اللغة الهدف."""
    if not text.strip():
        return ""

    if source_lang == target_lang:
        return text  # لا داعي للترجمة إن كانت اللغتان متطابقتين

    tokenizer, model = _load_model()

    src_code = _nllb_code(source_lang)
    tgt_code = _nllb_code(target_lang)

    tokenizer.src_lang = src_code
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)

    forced_bos_token_id = tokenizer.convert_tokens_to_ids(tgt_code)

    with torch.no_grad():
        generated_tokens = model.generate(
            **inputs,
            forced_bos_token_id=forced_bos_token_id,
            max_length=512,
            num_beams=4,
        )

    translated = tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]
    return translated.strip()


def translate_segments(segments: list[dict], source_lang: str, target_lang: str) -> list[dict]:
    """
    ترجمة قائمة من المقاطع (segments) الناتجة عن Whisper.
    كل مقطع يحتفظ بتوقيته الزمني الأصلي (start, end) مع إضافة النص المترجم.
    """
    translated_segments = []
    for seg in segments:
        translated_text = translate_text(seg["text"], source_lang, target_lang)
        translated_segments.append({
            "start": seg["start"],
            "end": seg["end"],
            "text": seg["text"],            # النص الأصلي
            "translated_text": translated_text,  # النص المترجم
        })
    return translated_segments
