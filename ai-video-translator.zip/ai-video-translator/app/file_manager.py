"""
file_manager.py
-----------------
مسؤول عن:
- إنشاء مجلدات مستقلة لكل Job (uploads/job_id, temp/job_id, outputs/job_id)
- التحقق من نوع وحجم الملف المرفوع
- تنظيف أسماء الملفات (Sanitization) لمنع الثغرات الأمنية
- حذف الملفات المؤقتة والقديمة تلقائياً
"""

import re
import shutil
import time
import uuid
import logging
from pathlib import Path

from app.settings import (
    UPLOAD_DIR, OUTPUT_DIR, TEMP_DIR,
    ALLOWED_VIDEO_EXTENSIONS, MAX_UPLOAD_SIZE_BYTES,
    FILE_RETENTION_HOURS,
)

logger = logging.getLogger("file_manager")


def generate_job_id() -> str:
    """توليد معرف فريد لكل مهمة جديدة."""
    return uuid.uuid4().hex[:16]


def sanitize_filename(filename: str) -> str:
    """
    تنظيف اسم الملف من أي رموز خطرة لمنع:
    - Path Traversal (../../etc/passwd)
    - حقن أوامر النظام
    يسمح فقط بالحروف والأرقام والشرطات والنقاط.
    """
    filename = Path(filename).name  # إزالة أي مسار مرفق بالاسم
    filename = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", filename)
    if not filename:
        filename = "file"
    return filename


def validate_video_file(filename: str, file_size: int) -> tuple[bool, str]:
    """
    التحقق من صلاحية ملف الفيديو المرفوع:
    - الامتداد مسموح به
    - الحجم ضمن الحد الأقصى المسموح
    يعيد (صحيح/خطأ، رسالة الخطأ إن وجدت)
    """
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_VIDEO_EXTENSIONS:
        return False, f"امتداد الملف غير مدعوم: {ext}. الامتدادات المسموحة: {', '.join(ALLOWED_VIDEO_EXTENSIONS)}"

    if file_size <= 0:
        return False, "حجم الملف غير صالح."

    if file_size > MAX_UPLOAD_SIZE_BYTES:
        max_mb = MAX_UPLOAD_SIZE_BYTES / (1024 * 1024)
        return False, f"حجم الملف يتجاوز الحد الأقصى المسموح ({max_mb:.0f} ميجابايت)."

    return True, ""


def create_job_dirs(job_id: str) -> dict:
    """
    إنشاء مجلد مستقل لكل Job في كل من:
    uploads/job_id - الملف الأصلي المرفوع
    temp/job_id    - الملفات الوسيطة أثناء المعالجة
    outputs/job_id - الفيديو النهائي وملفات الترجمة
    """
    paths = {
        "upload_dir": UPLOAD_DIR / job_id,
        "temp_dir": TEMP_DIR / job_id,
        "output_dir": OUTPUT_DIR / job_id,
    }
    for p in paths.values():
        p.mkdir(parents=True, exist_ok=True)
    return paths


def cleanup_temp_dir(job_id: str):
    """حذف مجلد الملفات المؤقتة الخاص بمهمة معينة بعد انتهاء المعالجة."""
    temp_path = TEMP_DIR / job_id
    if temp_path.exists():
        try:
            shutil.rmtree(temp_path)
            logger.info(f"تم حذف الملفات المؤقتة للمهمة {job_id}")
        except Exception as e:
            logger.error(f"فشل حذف الملفات المؤقتة للمهمة {job_id}: {e}")


def cleanup_old_files():
    """
    حذف الملفات والمجلدات القديمة (uploads, temp, outputs)
    التي تجاوز عمرها مدة FILE_RETENTION_HOURS.
    يتم استدعاؤها بشكل دوري (انظر main.py - background task).
    """
    cutoff = time.time() - (FILE_RETENTION_HOURS * 3600)
    for base_dir in [UPLOAD_DIR, TEMP_DIR, OUTPUT_DIR]:
        if not base_dir.exists():
            continue
        for job_dir in base_dir.iterdir():
            try:
                if job_dir.is_dir() and job_dir.stat().st_mtime < cutoff:
                    shutil.rmtree(job_dir)
                    logger.info(f"تم حذف المجلد القديم: {job_dir}")
            except Exception as e:
                logger.error(f"خطأ أثناء تنظيف الملفات القديمة في {job_dir}: {e}")
