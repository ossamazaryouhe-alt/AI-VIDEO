"""
queue_manager.py
-------------------
نظام طابور (Queue) محلي بسيط مبني على ThreadPoolExecutor، يضمن
عدم معالجة أكثر من MAX_CONCURRENT_JOBS فيديوهات في نفس الوقت،
لتفادي استنزاف الذاكرة والمعالج عند تشغيل عدة نماذج ذكاء اصطناعي معاً.

أي مهمة جديدة تُضاف إلى الطابور، وتُعالَج فور توفر "عامل" (worker) حر.
"""

import logging
from concurrent.futures import ThreadPoolExecutor

from app.settings import MAX_CONCURRENT_JOBS

logger = logging.getLogger("queue_manager")

# Executor مشترك لكل التطبيق، بعدد عمال محدود حسب الإعدادات
_executor = ThreadPoolExecutor(max_workers=MAX_CONCURRENT_JOBS, thread_name_prefix="job_worker")


def submit_job(func, *args, **kwargs):
    """
    إضافة مهمة جديدة إلى الطابور للمعالجة في الخلفية.
    تعيد كائن Future يمكن تتبع حالته إن لزم.
    """
    logger.info(f"تمت إضافة مهمة جديدة إلى الطابور: {func.__name__}")
    future = _executor.submit(func, *args, **kwargs)
    return future


def shutdown_queue(wait: bool = True):
    """إيقاف الطابور بشكل آمن (تُستدعى عند إغلاق التطبيق)."""
    _executor.shutdown(wait=wait)
