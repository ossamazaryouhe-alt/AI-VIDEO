"""
subtitle_generator.py
------------------------
توليد ملفات الترجمة النصية بصيغتي SRT و VTT من قائمة المقاطع المترجمة،
مع الحفاظ على التوقيت الأصلي لكل جملة.
"""

import logging

logger = logging.getLogger("subtitle_generator")


def _format_srt_timestamp(seconds: float) -> str:
    """تحويل الثواني إلى صيغة SRT: HH:MM:SS,mmm"""
    millis = int(round(seconds * 1000))
    hours, millis = divmod(millis, 3_600_000)
    minutes, millis = divmod(millis, 60_000)
    secs, millis = divmod(millis, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def _format_vtt_timestamp(seconds: float) -> str:
    """تحويل الثواني إلى صيغة VTT: HH:MM:SS.mmm"""
    millis = int(round(seconds * 1000))
    hours, millis = divmod(millis, 3_600_000)
    minutes, millis = divmod(millis, 60_000)
    secs, millis = divmod(millis, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"


def generate_srt(segments: list[dict], output_path: str, use_translated: bool = True):
    """
    إنشاء ملف SRT من قائمة المقاطع.
    use_translated: إذا True يستخدم translated_text، وإلا يستخدم النص الأصلي.
    """
    lines = []
    for i, seg in enumerate(segments, start=1):
        text = seg.get("translated_text") if use_translated else seg.get("text")
        text = (text or "").strip()
        if not text:
            continue
        start_ts = _format_srt_timestamp(seg["start"])
        end_ts = _format_srt_timestamp(seg["end"])
        lines.append(f"{i}\n{start_ts} --> {end_ts}\n{text}\n")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    logger.info(f"تم إنشاء ملف SRT: {output_path}")
    return output_path


def generate_vtt(segments: list[dict], output_path: str, use_translated: bool = True):
    """إنشاء ملف VTT من قائمة المقاطع."""
    lines = ["WEBVTT\n"]
    for seg in segments:
        text = seg.get("translated_text") if use_translated else seg.get("text")
        text = (text or "").strip()
        if not text:
            continue
        start_ts = _format_vtt_timestamp(seg["start"])
        end_ts = _format_vtt_timestamp(seg["end"])
        lines.append(f"{start_ts} --> {end_ts}\n{text}\n")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    logger.info(f"تم إنشاء ملف VTT: {output_path}")
    return output_path
